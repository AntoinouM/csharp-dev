#About The Project

This C# code is an implementation of the classic problem of the Tower of Hanoi, which involves moving a stack of disks from one rod to another. The program offers two algorithms to solve the problem, a recursive and an iterative one.


# Built With
VS Code
C#
Markdown
Dotnet

### Getting Started:
In the terminal:
        
        $dotnet run 

Watch terminal for feedback!

### Prerequisites
a functioning PC, Net6

### Installation
No installion needed other than dotnet.

### Usage: 
Do not use for conquering planet earth.

### Roadmap: 

### Contributing: 

### License: Whoever wants to use this code can use it.

### Contact
#### cc211012@fhstp.ac.at

### Acknowledgments
Thank you to Yun and Stackoverflow.