# Code Review Report
Course: C# Development SS 2023 (4 ECTS, 3 SWS)

Student ID: cc211036

BCC Group: B

Name: Antoine Muneret

#

### General Questions

- The name of the student you are reviewing: Hannah Schick - cc211012

- Did you run the code successfully? Did you run the code without problems by yourself, or did you get help from your colleague?
  Yes the code worked on first attempt. I just add to delete the obj and bin folders as it was provided in the zip.

- Is the output of the code correct?
  The output is correct

- Did the codes you are reviewing fulfill all requirements specified in the assignment?
  I think the the code fulfill the requirement if you are not strict on how the user input should be given.

- Do you understand the code logic and variables used?
  The logic is easy to understand.

### A Short Summary about the codes you reviewed: 
The code is an updated version of assignement 1. With this code we can no write generic method that worked with different kind of input. There is not much to say about this code, sam use as the first version but with the possibility of using different data types.

### Comments to Your Colleague
#### Strength:
(List down and explain the good parts of the codes. Please explain in detail.)
1. Straight-forward code that works well

#### Major Weakness:
(List down and explain major issues. Do you have a better solution? Please explain in detail.)
1. No comment, could help to understand what is called and how.
   

#### Minor Weakness:
(List down and explain minor issues. Please explain in detail.)
1. The interface could also have a printing method because both algorithms ae using one, making it type safe.
2. Some method coule be added to split the methods and helping with the code readability and maintenance. (a sorting method for the aguments, a converting method...)


### Reflections on Your Own Codes:
(List down and explain what you have learned from your colleague’s codes and what you should pay attention to when writing codes next time.)
1. I could also comment my code better.
2. I think my code is longer but would be easier to maintain due to use of classes.
3. If you use a space between arguments, the first one seems to be cut.