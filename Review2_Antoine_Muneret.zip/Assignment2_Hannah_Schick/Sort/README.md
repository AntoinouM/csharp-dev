# About The Project

This project is used to sort an array of different types using either bubble sort or merge sort. 


# Built With
VS Code
C#
Markdown
Dotnet

### Getting Started:
In the terminal:
        
        $ dotnet run 


Enter the data type of the array (int, string, double):

        $-string

Enter the strings to sort:

        $ zebra, lion, hippo, lizard

Receive sorted Array:

        hippo, lizard, lion, zebra

### Prerequisites
a functioning PC, Net6

### Installation
No installion needed other than dotnet.

### Usage: 
Do not use for conquering planet earth.

### Roadmap: 


### Contributing: 

### License: Whoever wants to use this code can use it.

### Contact
#### cc211012@fhstp.ac.at

### Acknowledgments
Thank you to Yun and Stackoverflow.